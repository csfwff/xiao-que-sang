package com.xiamo.xiaoquesang

import com.xiamo.xiaoquesang.common.BaseActivity

class MainActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun initView() {

          }


}
