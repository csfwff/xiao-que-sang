package com.xiamo.xiaoquesang.common

const val BaseUrl:String = ""
const val Version:String = ""


const val Preference:String = "XiaoQueSang"